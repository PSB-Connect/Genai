# python -m common_utilities.create_file

import json
import os
import re

# Template for the invoice text
TEMPLATE = """
Customer Name: {Customer Name}
Customer ID: {Customer ID}
Billing Account: {bill Account}

Purchase Order Number: {po Number}

Billing Address: {bill Address}
Service Address: {service Adress}

Invoice Number: {invoice Number}
Invoice Date: {date}
Invoice Amount: {invoice Amount}
Invoice Currency: {currency}

--- All Circuit Details ---
{circuit_details}
"""

def clean_key(key):   
    key = key.replace("\\n", "").replace("#", "").strip()
    # Keep hyphens for location fields
    if key in ["a-location", "b-location"]:
        return key
    return key.replace("-", "_").replace(" ", "_").lower()

def generate_comprehensive_invoice(json_file_path, output_folder):   
    try:
        with open(json_file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error reading {json_file_path}: {e}")
        return

    os.makedirs(output_folder, exist_ok=True)

    # Extract invoice-level fields
    invoice_fields = {
        "Customer Name": data.get("Customer Name", "N/A"),
        "Customer ID": data.get("Customer ID", "N/A"),
        "invoice Number": data.get("invoice Number", "N/A"),
        "bill Account": data.get("bill Account", "N/A"),
        "bill Address": data.get("bill Address", "N/A"),
        "service Adress": data.get("service Adress", "N/A"),
        "po Number": data.get("po Number", "N/A"),
        "date": data.get("date", "N/A"),
        "invoice Amount": data.get("invoice Amount", "N/A"),
        "currency": data.get("currency", "N/A"),
    }

    # Process all circuits in Tables
    circuit_details = []
    for table in data.get("Tables", []):
        if "circuitid" not in table:
            continue  # Skip summary rows

        # Prepare circuit fields
        circuit_info = {
            "circuitid": table.get("circuitid", "N/A"),
            "a-location": table.get("a-location", "N/A"),
            "b-location": table.get("b-location", "N/A"),
            "bandwidth": table.get("band\\nwidth", "N/A"),
            "mrc": table.get("mrc", "N/A"),
            "nonrec_chgs": table.get("nonrec\\nchgs", "N/A"),
            "total_charges": table.get("total\\ncharges", "N/A")
        }

        # Format each circuit's details
        circuit_text = f"""
Circuit ID: {circuit_info['circuitid']}
A End City: {circuit_info['a-location']}
B End City: {circuit_info['b-location']}
Bandwidth: {circuit_info['bandwidth']}
Monthly Recurring Charge: {circuit_info['mrc']}
Non Recurring Charge: {circuit_info['nonrec_chgs']}
Total Charges: {circuit_info['total_charges']}
---------------------------"""
        circuit_details.append(circuit_text)

    # Combine all circuit details
    all_circuit_details = "\n".join(circuit_details)

    # Merge all fields
    all_fields = {
        **invoice_fields,
        "circuit_details": all_circuit_details
    }

    # Fill the template
    try:
        filled_template = TEMPLATE.format(**all_fields)
    except KeyError as e:
        print(f"Missing key {e} in {json_file_path}")
        return

    # Generate output filename
    output_filename = f"invoice_{invoice_fields['invoice Number']}.txt"
    output_path = os.path.join(output_folder, output_filename)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(filled_template.strip())

    print(f"Generated comprehensive invoice: {output_filename}")

def process_folder(input_folder, output_folder):
    """Process all JSON files in a folder"""
    for filename in os.listdir(input_folder):
        if filename.endswith(".json"):
            file_path = os.path.join(input_folder, filename)
            generate_comprehensive_invoice(file_path, output_folder)

# Configuration
INPUT_FOLDER = r"C:\Badri\Projects\Python\POC-2\data\json_files"
OUTPUT_FOLDER = r"C:\Badri\Projects\Python\POC-2\data\output"

# Run the processor
print(f"Processing JSON files from {INPUT_FOLDER}")
print(f"Saving output files to {OUTPUT_FOLDER}")
process_folder(input_folder=INPUT_FOLDER, output_folder=OUTPUT_FOLDER)
print("Processing complete!")